package com.server.mapper;

import com.server.dto.UserDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {
    // 유저 아이디를 가져오는 작업
    @Select("SELECT * FROM `user` where `id` = #{id}")
    UserDTO selectUserById(@Param("id") String id);
}
