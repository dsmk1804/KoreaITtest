// 좋아요 버튼을 누르면 좋아요 수가 오르도록 하는 함수

// 초기에는 0으로 고정이다.
var likeClickCount = 0;
var likeCountTag = document.getElementById("like-btn");







