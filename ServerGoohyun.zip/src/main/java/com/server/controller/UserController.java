package com.server.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {
    // 사용자가 로그인 페이지로 넘어갈 수 있게 해주는 페이지
    @GetMapping("/user/login")
    public void get_login(){}

}
