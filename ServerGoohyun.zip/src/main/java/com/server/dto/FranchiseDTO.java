package com.server.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
public class FranchiseDTO {
    private int no; // 순번
    private String name; //가게명
    private String phone; // 전화번호
    private String post; // 도로명 주소
    private Timestamp dayOpen; // 평일 운영 시간
    private Timestamp satOpen; // 토요일 운영 시간
    private boolean delivery; // 배달 가능 여부
    private int like; // 좋아요 수


}
