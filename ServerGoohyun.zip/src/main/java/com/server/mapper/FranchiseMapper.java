package com.server.mapper;

public interface FranchiseMapper {

}
